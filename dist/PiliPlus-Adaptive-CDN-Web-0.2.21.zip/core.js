(function (root, factory) {
  const api = factory();
  root.PiliPlusAdaptiveCdnCore = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis === "object" ? globalThis : this, function () {
  "use strict";

  const DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    preferredCodec: "hevc",
    expandKnownUpos: false,
    targetBufferSec: 30,
    segmentToleranceSec: 10,
    lowBufferSec: 10,
    bufferStallSec: 5,
    endToleranceSec: 5,
    cooldownSec: 60,
    failCooldownMs: 2000,
    traverseAllCdns: true,
    maxSwitches: 3,
    stableRewardSec: 30,
  });

  const NUMBER_RANGES = Object.freeze({
    targetBufferSec: [5, 120],
    segmentToleranceSec: [0, 30],
    lowBufferSec: [2, 30],
    bufferStallSec: [2, 60],
    endToleranceSec: [0, 10],
    cooldownSec: [0, 600],
    failCooldownMs: [0, 15000],
    maxSwitches: [1, 50],
    stableRewardSec: [10, 300],
  });
  const MIN_BUFFER_GROWTH_SEC = 1;

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function normalizeSettings(input) {
    const source = input && typeof input === "object" ? input : {};
    const output = { ...DEFAULT_SETTINGS };
    for (const key of ["enabled", "preferAv1", "expandKnownUpos", "traverseAllCdns"]) {
      if (typeof source[key] === "boolean") output[key] = source[key];
    }
    if (["av1", "hevc", "avc", "default"].includes(source.preferredCodec)) {
      output.preferredCodec = source.preferredCodec;
    } else if (source.preferAv1 === false) {
      output.preferredCodec = "default";
    }
    for (const [key, [min, max]] of Object.entries(NUMBER_RANGES)) {
      const value = Number(source[key]);
      if (Number.isFinite(value)) output[key] = clamp(value, min, max);
    }
    return output;
  }

  function hostOf(value) {
    try {
      return new URL(String(value), "https://www.bilibili.com").hostname;
    } catch (_) {
      return "";
    }
  }

  function resourceKey(value) {
    try {
      const url = new URL(String(value), "https://www.bilibili.com");
      return url.pathname;
    } catch (_) {
      return "";
    }
  }

  function isMediaUrl(value) {
    const host = hostOf(value);
    if (!host) return false;
    return (
      host.endsWith(".bilivideo.com") ||
      host.endsWith(".bilivideo.cn") ||
      host.endsWith(".akamaized.net")
    );
  }

  function isPlayUrlApi(value) {
    try {
      const url = new URL(String(value), "https://www.bilibili.com");
      return (
        /(^|\/)playurl(?:v2)?(?:\/|$)/i.test(url.pathname) ||
        /\/player\/(?:wbi\/)?playurl/i.test(url.pathname)
      );
    } catch (_) {
      return false;
    }
  }

  function uniqueUrls(values) {
    const result = [];
    const seen = new Set();
    for (const value of values || []) {
      if (typeof value !== "string" || !isMediaUrl(value) || seen.has(value)) {
        continue;
      }
      seen.add(value);
      result.push(value);
    }
    return result;
  }

  function scoreOf(scores, urlOrHost) {
    const host = urlOrHost.includes?.("://") ? hostOf(urlOrHost) : urlOrHost;
    const value = Number(scores?.[host]);
    return Number.isFinite(value) ? value : 50;
  }

  function rankCandidates(values, scores, cooldowns, failedHosts, now = Date.now()) {
    return uniqueUrls(values)
      .map((url, index) => ({ url, index, host: hostOf(url) }))
      .filter(({ host }) => {
        if (!host || failedHosts?.has(host)) return false;
        return Number(cooldowns?.[host] || 0) <= now;
      })
      .sort((a, b) => scoreOf(scores, b.host) - scoreOf(scores, a.host) || a.index - b.index)
      .map(({ url }) => url);
  }

  function streamUrls(stream) {
    if (!stream || typeof stream !== "object") return [];
    const list = value => Array.isArray(value) ? value : [value];
    return uniqueUrls([stream.baseUrl, stream.base_url,
      ...list(stream.backupUrl), ...list(stream.backup_url)]);
  }

  function streamKind(stream) {
    const mime = String(stream?.mimeType || stream?.mime_type || "").toLowerCase();
    const codec = String(stream?.codecs || "").toLowerCase();
    if (mime.startsWith("audio/")) return "audio";
    if (mime.startsWith("video/")) return "video";
    if (/^(mp4a|ec-3|ac-3|opus)/.test(codec)) return "audio";
    return codecFamily(stream?.codecs) ? "video" : "";
  }

  function selectSwitchTargets(resources, failedResource) {
    if (failedResource) return [failedResource];
    const video = resources.filter((resource) => resource.kind === "video");
    return video.length ? video : resources;
  }

  function collectStreams(rootValue) {
    const streams = [];
    const visited = new Set();
    function walk(value, depth) {
      if (!value || typeof value !== "object" || depth > 9 || visited.has(value)) return;
      visited.add(value);
      if (streamUrls(value).length) streams.push(value);
      if (Array.isArray(value)) {
        for (const item of value) walk(item, depth + 1);
      } else {
        for (const child of Object.values(value)) walk(child, depth + 1);
      }
    }
    walk(rootValue, 0);
    return streams;
  }

  function codecFamily(codec) {
    const value = String(codec || "").toLowerCase();
    if (value.startsWith("av01")) return "av1";
    if (value.startsWith("hev1") || value.startsWith("hvc1")) return "hevc";
    if (value.startsWith("avc1")) return "avc";
    return "";
  }

  function reorderVideoArrays(rootValue, preferredCodec, canPlayCodec) {
    if (preferredCodec === true) preferredCodec = "av1";
    if (!preferredCodec || preferredCodec === "default" || !rootValue || typeof rootValue !== "object") return;
    const visited = new Set();
    function walk(value, depth) {
      if (!value || typeof value !== "object" || depth > 8 || visited.has(value)) return;
      visited.add(value);
      if (Array.isArray(value.video) && value.video.some((item) => codecFamily(item?.codecs) === preferredCodec)) {
        value.video.sort((a, b) => {
          if (a?.id !== b?.id) return Number(b?.id || 0) - Number(a?.id || 0);
          return (
            Number(canPlayCodec?.(b?.codecs) && codecFamily(b?.codecs) === preferredCodec) -
            Number(canPlayCodec?.(a?.codecs) && codecFamily(a?.codecs) === preferredCodec)
          );
        });
      }
      for (const child of Object.values(value)) walk(child, depth + 1);
    }
    walk(rootValue, 0);
  }

  function createHealthState(now = 0) {
    return {
      lastBuffered: 0,
      lastBufferProgressAt: now,
      refillStartForward: 0,
      bufferBelowTarget: false,
      lastPosition: 0,
      lastPositionProgressAt: now,
      lastSwitchAt: -Infinity,
      wasTrying: false,
    };
  }

  function resetAtMediaTail(state, sample, now) {
    state.lastBuffered = sample.buffered;
    state.lastBufferProgressAt = now;
    state.refillStartForward = 0;
    state.bufferBelowTarget = false;
    state.lastPosition = sample.position;
    state.lastPositionProgressAt = now;
  }

  function evaluateHealth(state, sample, rawSettings, now) {
    const settings = normalizeSettings(rawSettings);
    const duration = Number(sample.duration) || 0;
    const position = Number(sample.position) || 0;
    const buffered = Math.max(position, Number(sample.buffered) || 0);
    // `video.paused === false` becomes true as soon as play() is accepted,
    // which can be several seconds before the first frame is actually ready.
    // Do not start the CDN-stall clock during that normal startup window.
    const trying =
      Boolean(sample.playing) && sample.hasStartedPlayback !== false && !sample.ended;
    const atTail =
      duration > 0 &&
      position + settings.endToleranceSec >= duration &&
      buffered + Math.min(2, settings.endToleranceSec) >= duration;

    if (atTail) {
      resetAtMediaTail(state, { position, buffered }, now);
      return null;
    }

    const positionDelta = Math.abs(position - state.lastPosition);
    const forward = Math.max(0, buffered - position);
    const startedTrying = trying && !state.wasTrying;
    state.wasTrying = trying;
    if (startedTrying) {
      // Starting or resuming playback begins a new observation window. Time
      // spent loading or explicitly paused must not count toward a CDN stall.
      state.lastBufferProgressAt = now;
      state.refillStartForward = forward;
      state.bufferBelowTarget = false;
    }
    if (positionDelta >= 2 && (buffered < state.lastBuffered || forward <= 1)) {
      state.lastBuffered = buffered;
      state.lastBufferProgressAt = now;
      state.refillStartForward = forward;
      state.bufferBelowTarget = false;
      state.lastPosition = position;
      state.lastPositionProgressAt = now;
      state.lastSwitchAt = now;
      return null;
    }
    if (positionDelta >= 0.25 || !trying) {
      state.lastPosition = position;
      state.lastPositionProgressAt = now;
    }


    state.lastBuffered = buffered;

    const targetFloor = Math.min(
      settings.targetBufferSec,
      Math.max(
        settings.lowBufferSec + settings.segmentToleranceSec,
        settings.targetBufferSec - settings.segmentToleranceSec,
      ),
    );
    if (forward >= targetFloor) {
      state.bufferBelowTarget = false;
      return null;
    }
    if (!state.bufferBelowTarget) {
      state.bufferBelowTarget = true;
      state.lastBufferProgressAt = now;
      state.refillStartForward = forward;
      return null;
    }
    if (trying && now - state.lastBufferProgressAt >= settings.bufferStallSec * 1000) {
      const growth = forward - state.refillStartForward;
      state.lastBufferProgressAt = now;
      state.refillStartForward = forward;
      if (growth >= MIN_BUFFER_GROWTH_SEC) return null;
      state.bufferBelowTarget = false;
      state.lastSwitchAt = now;
      return "buffer-stall";
    }
    return null;
  }

  function shouldPauseForVideoFrameStall(sample, now) {
    const frameGraceAt = Math.max(
      Number(sample.lastFrameAt) || 0,
      Number(sample.playStartedAt) || 0,
    );
    return (
      sample.playing &&
      sample.hasStartedPlayback !== false &&
      !sample.seeking &&
      now >= (Number(sample.recoveryUntil) || 0) &&
      (Number(sample.forwardBuffer) || 0) >= (Number(sample.minForwardBuffer) || 0) &&
      sample.position - sample.lastFramePosition >= 0.5 &&
      now - frameGraceAt >= 8000
    );
  }

  function shouldSwitchForRequestFailure(status, aborted) {
    return !aborted && (status == null || (status !== 200 && status !== 206));
  }

  function createNetworkGuardState() {
    return { samples: [], pauseUntil: 0 };
  }

  function shouldPauseNetworkSwitch(state, sample, now) {
    if (now < state.pauseUntil) return true;
    state.samples = state.samples.filter((item) => now - item.at <= 15_000);
    state.samples.push({ at: now, host: sample.host, kind: sample.kind });
    const hosts = new Set(state.samples.map((item) => item.host).filter(Boolean));
    const kinds = new Set(state.samples.map((item) => item.kind).filter(Boolean));
    const looksGlobal =
      state.samples.length >= 3 &&
      (state.samples.length >= 4 || hosts.size >= 2 || kinds.size >= 2);
    if (!looksGlobal) return false;
    state.samples = [];
    state.pauseUntil = now + 20_000;
    return true;
  }

  return Object.freeze({
    DEFAULT_SETTINGS,
    normalizeSettings,
    hostOf,
    resourceKey,
    isMediaUrl,
    isPlayUrlApi,
    uniqueUrls,
    scoreOf,
    rankCandidates,
    streamUrls,
    streamKind,
    selectSwitchTargets,
    collectStreams,
    codecFamily,
    reorderVideoArrays,
    createHealthState,
    evaluateHealth,
    shouldPauseForVideoFrameStall,
    shouldSwitchForRequestFailure,
    createNetworkGuardState,
    shouldPauseNetworkSwitch,
  });
});
